package src_unpack;
import java.io.*;
import java.util.*;

import javax.swing.JOptionPane;

import java.net.*;

public class server_read {
	
	private String hostname = "127.0.0.1";
	private int port = 8000;
	public ArrayList bir_file = new ArrayList ();
	
	
	public server_read() throws IOException{
		
		Socket sok = null;
		
		try {
			sok = new Socket(hostname,port);
		} 
		catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Server Connect Fail!!",null,JOptionPane.ERROR_MESSAGE);
		}
		
		InputStream in_file = sok.getInputStream();
		int length = in_file.read();
		
		while(length != -1){
			bir_file.add(length);
			length = in_file.read();
		}		
	}
}
