package src_pack;
import java.io.*;
import java.util.*;

public class make_dir {
	
	public make_dir() throws IOException{
		File make = new File("./suprise");
		make.mkdirs();
	}

}
