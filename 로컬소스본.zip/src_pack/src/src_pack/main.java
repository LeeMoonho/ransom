package src_pack;
import java.io.*;

public class main {

	public static void main(String[] args) throws IOException {
		
		make_dir make_dir = new make_dir();
		cryp cryp = new cryp();
		creat_web creat_web = new creat_web();
		
		String[] cmdArray = {"rundll32", "url.dll", "FileProtocolHandler",".\\suprise\\hello.html"};
		Process p = Runtime.getRuntime().exec(cmdArray);

	}
}
