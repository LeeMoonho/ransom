package src_unpack;
import java.io.*;
import java.net.Socket;
import java.util.*;
import javax.swing.JOptionPane;

public class File_decryp extends view_file{
	
	public File_decryp() throws IOException{
	
		ArrayList creat_file = new ArrayList();
		
		int i = 0, save = 0, count = 0;
		
		while(i <= super.File_save.size()-1){
			server_read server_read = new server_read();
			int array_count = server_read.bir_file.size() -1;
			
			String name = (String) super.File_save.get(i).toString();
			String out_name = name.replaceAll("._mh", "");
			
			FileInputStream in = new FileInputStream(name);
			FileOutputStream out = new FileOutputStream(out_name);
			
			
			while((save = in.read()) != -1){
				
				if(array_count == -1){
					array_count = server_read.bir_file.size() -1;
				}
				
				save = save - (int) server_read.bir_file.get(array_count);
				
				creat_file.add(save);
				
				out.write((int) creat_file.get(count));
				array_count --;
				count ++;
			}
			
			out.close();
			in.close();
			i++;
			
			File remove = new File(out_name+"._mh");
			
			 if (!remove.isDirectory()) {
				 remove.delete();
			 }
			 
		}
		 JOptionPane.showMessageDialog(null, "Decryptiont Success!!");						
	}

}
