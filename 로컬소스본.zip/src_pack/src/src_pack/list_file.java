package src_pack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class list_file {
	
	public ArrayList File_save = new ArrayList();
	
	public list_file(){
		
		String home_dir = System.getProperty("user.home");
		String dir = home_dir +"\\Desktop";
		list_file(dir);
	}
	
	public void list_file(String name2){
		
		File dir_file = new File(name2);
		File [] file_name = dir_file.listFiles();
		
		for(File name : file_name){
			
			if(name.isDirectory()){
				try {
					list_file(name.getCanonicalFile().toString());
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			else if(name.isFile()){
								
				if(name.getName().equals("dlansgh.txt")){
					System.out.println("hahahaha");
				}
				else{
					File_save.add(name);	
				}

			}
		}
		
	}
	

}
