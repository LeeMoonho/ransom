package src_unpack;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ListModel;

import java.awt.Panel;
import java.awt.Color;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.Toolkit;

public class unpack_main extends JFrame {

	private JPanel contentPane;
	public JList list = new JList();
	public DefaultListModel model = new DefaultListModel();
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					unpack_main frame = new unpack_main();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public unpack_main(){
		setIconImage(Toolkit.getDefaultToolkit().getImage(unpack_main.class.getResource("/src_unpack/3e7d314aecbcd620c92b5886c7c9d222.png")));
		setTitle("Moon_Decryption_v1.0");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 466, 348);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 98, 206, 199);
		contentPane.add(scrollPane);
		scrollPane.setViewportView(list);

		//scaning click
		JButton btnNewButton = new JButton("Scaning");
		
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				model.clear();
				JOptionPane.showMessageDialog(null, "Scaning....Please wait");
				scan_file();
			}
		});
		
		
		btnNewButton.setBounds(12, 20, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Decryption");
		
		//Click decryp
		btnNewButton_1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e){
				try {
					decryp();
				} 
				catch (IOException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		
		btnNewButton_1.setBounds(121, 20, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Server Connecting Test");
		
		//Server Connecting Cilck
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Server_connect server_connect = new Server_connect();
			}
		});
		
		
		btnNewButton_2.setBounds(12, 58, 206, 23);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setIcon(new ImageIcon(unpack_main.class.getResource("/src_unpack/moonho.jpg")));
		lblNewLabel.setBounds(0, 0, 467, 320);
		contentPane.add(lblNewLabel);
	}
	
	
	public void scan_file(){
		
		list.setModel(model);
		int i = 0;
		view_file view_file = new view_file();
		
		while(i < view_file.File_save.size()){
			model.addElement(view_file.File_save.get(i));
			i++;
		}
		JOptionPane.showMessageDialog(null, "Scan Finsh!!");	
		
	}
	
	
	public void decryp() throws IOException {

		File_decryp file_decryp = new File_decryp();
		
	}
	
	
}
