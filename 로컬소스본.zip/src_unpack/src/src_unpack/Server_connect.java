package src_unpack;
import java.io.*;
import java.net.*;
import javax.swing.JOptionPane;

public class Server_connect {
	
	private String hostname = "127.0.0.1";
	private int port = 8000;
	
	public Server_connect(){
		
		try {
			
			Socket sok = new Socket(hostname,port);
			JOptionPane.showMessageDialog(null, "Server Connect Success!!");
		} 
		
		catch (IOException e) {
			
			JOptionPane.showMessageDialog(null, "Server Connect Fail!!",null,JOptionPane.ERROR_MESSAGE);
		}
		
	}

}
