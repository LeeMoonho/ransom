package src_unpack;
import java.io.*;
import java.util.*;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class view_file extends unpack_main{
	
	public ArrayList File_save = new ArrayList();
	
	public view_file(){
		
		String home_dir = System.getProperty("user.home");
		
		String dir = home_dir +"\\Desktop";
		view_file(dir);
	}
	
	public void view_file(String name2){
		
		File dir_file = new File(name2);
		File [] file_name = dir_file.listFiles();

		for(File name : file_name){
			
			if(name.isDirectory()){
				try {
					view_file(name.getCanonicalFile().toString());
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
			}
			else if(name.getName().endsWith("._mh")){
				File_save.add(name);
			}
		}
		
	}
	

}
